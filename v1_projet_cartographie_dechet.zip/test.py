x = 3

def f(y):
    print(x + y)

f(4)